package com.yazan.loginandregistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginandregistrationApplicationTests {

    @Test
    void contextLoads() {
    }

}
