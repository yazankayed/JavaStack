package com.axsos.javaexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaExamApplication {

    public static void main(String[] args) {
        SpringApplication.run(JavaExamApplication.class, args);
    }

}
